title: 【linux】网络聊天室Socket编程
date: '2019-01-22 11:16:19'
updated: '2019-04-19 16:25:16'
tags: [linux, socket, C语言]
permalink: /articles/2019/01/22/1548126821667.html
---
 这是18年7月写的，拿来填充一下:stuck_out_tongue_winking_eye:
 
----
   linux下的网络聊天室，服务端，c客户端，java客户端，Android端 基于TCP开发 源代码 附有udp socket 服务端 客户端
 
**  [下载链接](https://img.hacpai.com/file/2019/04/网络聊天室源代码-c1a6c8a9.zip)**

**服务器端**

    void SendMsg(char *msg){
		  int i;
		  char tempmsg[286];
		  strcpy(tempmsg, msg);
		  char nowtime[10];
		  char sendbuffer[500] = {}; //最终消息发送
		  time_t t;
		  struct tm *lt;
		  time(&t);
		  lt = localtime(&t);
		  sprintf(nowtime, "[%d:%d:%d]", lt->tm_hour, lt->tm_min, lt->tm_sec);

		  strcat(sendbuffer, nowtime);
		  strcat(sendbuffer, tempmsg);
		  for (i = 0; i < MAXNUM; ++i)
		  {
			  if (clientSock[i] != 0)
			  {
				  printf("发送至客户[ %d ]\n", clientSock[i]);
				  send(clientSock[i], sendbuffer, strlen(sendbuffer), 0);
			  }
		  }

		  FILE * wfile = fopen("./allmsg.txt","a+");
		  fwrite(sendbuffer,strlen(sendbuffer),1,wfile);
		  fwrite("\n",strlen("\n"),1,wfile);
		  fclose(wfile);
		  printf("消息记录完毕\n");
		  printf("===================\n");
		  }
		  void *userthread(void *arg){

		  //char sendmsg[300];
		  int usersock = *(int *)arg;
		  printf("客户 Socket[ %d ]:\n", usersock);
		  while (1)
		  {
			  char usermsg[286] = {};
			  //memset(sendmsg, 0, sizeof(sendmsg));
			  memset(usermsg, 0, sizeof(usermsg));
			  if (recv(usersock, usermsg, sizeof(usermsg), 0) <= 0)
			  {
				  int i;
				  for (i = 0; i < MAXNUM; ++i)
				  {
					  if (usersock == clientSock[i])
					  {
						  clientSock[i] = 0;
						  break;
					  }
				  }

				  printf("用户 %d 已退出!\n", usersock);
				  pthread_exit((void *)i);
			  }

			  if(strcmp(usermsg,"[online]")==0)
			  {
				  printf("%d客户端查询消息记录\n",usersock);
				  FILE * sendfile = fopen("./allmsg.txt","r");
				  char allmsg[1024*10]={};
				  char allmsgsend[1024*11] = {};
				  fread(allmsg,sizeof(allmsg),1,sendfile);
				  strcat(allmsgsend,"\n--------漫游记录--------\n");
				  strcat(allmsgsend,allmsg);
				  strcat(allmsgsend,"\n-------漫游记录查询完毕---\n");
				  send(usersock,allmsgsend,strlen(allmsgsend),0);
				  fclose(sendfile);
				  printf("==================\n");
				  continue;
			  }
			  SendMsg(usermsg);
		  }
    }

     int main(){
			severSock = socket(AF_INET, SOCK_STREAM, 0);
			struct sockaddr_in severAddr;
			memset(&severAddr, 0, sizeof(severAddr));
			severAddr.sin_family = AF_INET;
			severAddr.sin_addr.s_addr = inet_addr(IP);
			severAddr.sin_port = htons(PORT);

			if (bind(severSock, (struct sockaddr *)&severAddr, sizeof(severAddr)) == -1)
			{
				perror("绑定失败！！！");
				exit(-1);
			}
			if (listen(severSock, MAXNUM) == -1)
			{
				perror("监听失败!!!");
				exit(-1);
			}
			printf("|****服务器启动成功****|\n");
			// struct sockaddr_in tempaddr;
			// socklen_t len = sizeof(tempaddr);

			while (1)
			{
				struct sockaddr_in tempaddr;
				socklen_t len = sizeof(tempaddr);
				//memset(&tempaddr, 0, sizeof(tempaddr));
				int sockid = accept(severSock, (struct sockaddr *)&tempaddr, &len);
				if (sockid == -1)
				{
					printf("客户端连接失败!!!\n");
					continue;
				}
				int i = 0;
				for (i = 0; i < MAXNUM; ++i)
				{
					if (clientSock[i] == 0)
					{
						clientSock[i] = sockid;
						printf("新的客户端已连接，socket: %d\n", sockid);
						pthread_t userthrd;
						pthread_create(&userthrd, 0, userthread, &sockid);
						break;
					}

					if (i == MAXNUM)
					{
						char *str = "不好意思，满员了。";
						send(sockid, str, strlen(str), 0);
						close(sockid);
					}
				}
			}
    }





