title: Solo，你好！关于搭建博客介绍
date: '2019-01-22 10:57:56'
updated: '2019-01-22 11:05:54'
tags: [个人, 技术]
permalink: /hello-solo
---
 ![](https://img.hacpai.com/bing/20171106.jpg?imageView2/1/w/960/h/520/interlace/1/q/100) 

本站使用 [Solo](https://github.com/b3log/solo) 博客系统。

另外，如果你对这方面也很感兴趣的话，欢迎你加入[黑客与画家的社区](https://hacpai.com)，你可以使用博客账号直接登录！

----
   
   本站服务器 阿里服务器 
   系统  linux  centOs 7.6
   环境搭建 网上有，其实最重要的还是对tomcat熟不熟悉，本站在搭建时，没有使用Nginx，其他都大同小异