title: 【毕设_4】simpleWIFI模块_数据保存
date: '2019-01-26 10:53:44'
updated: '2019-04-19 19:44:07'
tags: [毕设, stm32, WIFI, socket]
permalink: /articles/2019/01/26/1548470043733.html
---
**一：java端进行获取端口数据**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;java socket获取数据

**二：java 连接mysql数据库**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;从端口获取来的数据，保存到数据库，java程序用jar封装，可以直接部署到服务器，在服务器运行

**三：simpleWIFI模块至此全部测试结束了**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;结下来就应该调试GY-30 光照强度模块，货还没到
