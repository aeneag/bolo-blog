title: 【毕设_2】simpleWIFI模块_局域网
date: '2019-01-24 15:13:49'
updated: '2019-04-19 21:01:24'
tags: [C语言, 毕设, stm32, WIFI]
permalink: /articles/2019/01/24/1548313914476.html
---
![](https://img.hacpai.com/bing/20181125.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**simpleWIFI模块说明**
---

![e92a19a0d4c94a36b36c5cd9d52fa34f_Xshot0019.png](https://img.hacpai.com/file/2019/04/e92a19a0d4c94a36b36c5cd9d52fa34fXshot0019-63ec6b3b.png)
![9405d3e084a14127813fde7da95734aa_Xshot0020.png](https://img.hacpai.com/file/2019/04/9405d3e084a14127813fde7da95734aaXshot0020-cfeddefd.png)
![368a1369c5e14643b4c1045ea8740c24_Xshot0016.png](https://img.hacpai.com/file/2019/04/368a1369c5e14643b4c1045ea8740c24Xshot0016-6d1aab45.png)


**下图是与奋斗stm32开发板USART2接口：**
---

![43b37ccf8c4347ef89162ee4ae4697cc_Xshot0017.png](https://img.hacpai.com/file/2019/04/43b37ccf8c4347ef89162ee4ae4697ccXshot0017-7fcea335.png)

**下图是simpleWIFI模块与奋斗stm32开发板的连接：**
---

![f0236c0212c14cbfa071fe1cc27635a2_Xshot0018.png](https://img.hacpai.com/file/2019/04/f0236c0212c14cbfa071fe1cc27635a2Xshot0018-ad1089dc.png)

**simpleWIFI模块的使用**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;simpleWIFI模块在局域网下是不用对simpleWIFI模块配置的，只要线连接对，代码写的正确，就可以进行通信，虽然说起来很简单，但是也是花了很长的时间才一点一点搞明白这个模块。<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;stm32开发板对USART2 GPIO 的初始化就很简单了，如果这个都不会，那就不能愉快的玩耍了。<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;那么如何知道是成功了呢，我们可以用网络串口助手，也可以通过dos窗口。首先，电脑先连接上simpleWIFI,打开dos窗口，输入

      telnet 192.1683.2.1 8000  //这是simpleWIFI模块默认的
	  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;如果出现你在stm32开发板向USART2串口发送的内容，说明成功了

