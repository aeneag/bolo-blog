title: 【毕设_9】stm32单片机程序ing
date: '2019-04-07 22:03:58'
updated: '2019-04-20 14:50:39'
tags: [毕设, C语言, stm32]
permalink: /articles/2019/04/07/1554642487139.html
---
![](https://img.hacpai.com/bing/20180830.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**一、程序基本完成**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;传感器模块已完成，期间也碰到许多问题，像pwm出了问题搞了三个晚上，还有灯泡打开导致simpleWIFI模块电压不足等问题

**二、通信协议**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;刚设计好通信协议，下图，还未写入，待完成
![587a46ef03204856a94f688d82d7cba0_.JPG](https://img.hacpai.com/file/2019/04/587a46ef03204856a94f688d82d7cba0-008c66e6.JPG)

**三、LCD显示模块**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;LCD显示模块还未开始，此模块较简单

**四、Server**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;服务器采用阿里linux服务器，Apache+tomcat+javaee
![542a7a7abe354cba9ba26421cb95d121.png](https://img.hacpai.com/file/2019/04/542a7a7abe354cba9ba26421cb95d121-87de9772.png)

**五、Client**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;App客户端慢慢来吧 
* [ ] * [ ] 