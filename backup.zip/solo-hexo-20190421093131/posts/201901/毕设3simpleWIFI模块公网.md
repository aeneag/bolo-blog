title: 【毕设_3】simpleWIFI模块_公网
date: '2019-01-25 22:33:45'
updated: '2019-04-19 19:43:58'
tags: [毕设, stm32, WIFI, C语言]
permalink: /articles/2019/01/25/1548426241471.html
---
**一：simpleWIFI模块**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;把simpleWIFI模块调整为STA模式，连接到电脑所在的无线WIFI上，组成联网的局域网。. 

**二：花生壳内网映射**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在花生壳开通账户，购买一个域名，加体验版的内网映射，5+6 11块钱应该不贵吧，如果你是土豪你可以开更好的。然后进行配置，内网映射。映射成功后，就可以访问了  比如我的 aeneag.xicp.io xxxxx  端口号就不说了

**三：java端进行获取端口数据**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;获取数据用的是socket，开一个接收线程，很简单的就可以获取数据了。

**总之**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;只要把simpleWIFI模块彻底搞明白了，其他的都好说。