title: soloBlog部署过程
date: '2019-04-20 20:50:09'
updated: '2019-04-20 22:23:59'
tags: [个人, Solo]
permalink: /articles/2019/04/20/1555764609590.html
---
## Preface

&nbsp;&nbsp;&nbsp;&nbsp;去年12月突然想搭一个属于自己的博客，就从网上搜开源的blog，当然网上还有同学介绍的最多的还是是WordPress，但是奈何自己对php不是很熟悉，就放弃了。对于我个人来说，还是java比较熟悉，然后就从网海里中寻找，机缘巧合下，找到了solo，自这之后就爱上了，也许这就是缘分，哈哈。本来很想写从零搭建的过程，一直没有机会，感觉社区有好多东西也没说的很具体，这几天有空把solo升到了最新，至此也想写一篇来说一说搭建博客过程中的坑，其实最艰难的还是去年12月底的那个时候，对solo很陌生，准备安装配置其他东西都很简单，愣是到了配solo各种问题，搞的自己很难受，版本3.0之后也变了好多。

---
## 一、准备工作
### 1. Centos
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;我用的是阿里服务器，系统Centos7.6,买的具体步骤就不用说了，安装成功后，用 xshell这个软件远程登录，登录上之后Centos系统可能会出现一个警告:
>       WARNINNG The remote SSH server rejected X11 forwarding request.

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;解决办法：
```
           yum install xorg-x11-font* xorg-x11-xauth
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;然后在 /etc/ssh/sshd_config  文件中,找到下面两个参数，刚开始是被注释的，改完保存退出

>             X11Forwarding //设置为yes
>             UseLogin  //设置为no

### 2. JDK配置
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其实这很简单，就算自己不会百度有很多
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1）官网下载 JDK linux版本
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2）解压
>           tar -zxvf jdk-8u144-linux-x64.tar.gz

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3）配置环境变量

>       /usr/lib/jvm/jdk1.8.0_191   //这是我解压后的路径

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;打开文件

>        vi  /etc/profile

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在最后一行输入

>         #java environment
>         export JAVA_HOME=/usr/java/jdk1.8.0_144
>         export CLASSPATH=.:${JAVA_HOME}/jre/lib/rt.jar:${JAVA_HOME}/lib/dt.jar:${JAVA_HOME}/lib/tools.jar
>         export PATH=$PATH:${JAVA_HOME}/bin

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;保存退出，并执行

>          source  /etc/profile    //使刚才的环境变量生效
>          java -version          //检查一下是否成功

### 3. Tomcat安装
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1）官网下载 tomcat 版本 ` apache-tomcat-9.0.14.tar.gz` 这是我下载的
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2）解压

>         tar -zxvf apache-tomcat-9.0.14.tar.gz

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3）如果没有什么太大的问题，这个时候在  ` /bin`目录下 执行  ` ./startup.sh` 就可以运行了
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4）关于端口更改和配置solo后面再说

### 4. Mysql安装
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;执行以下命令：

>         cd /usr/local/src/   
>         wget http://repo.mysql.com/mysql57-community-release-el7-8.noarch.rpm
>         rpm -ivh mysql57-community-release-el7-8.noarch.rpm
>         yum -y install mysql-server

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其他安装问题自行百度吧，安装Mysql的过程很详细

### 5. 购买域名+SSL证书
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;买的全部是阿里的

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;上面的貌似是我年前不知什么时候整理的，现在再整理一次，也是第一次这样写这个，可能有些地方写的不太好。

---
## 二、安装配置solo
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1） 下载 solo war包，放到tomcat webapps文件夹下
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2） 在今年年初的时候，也就是2点几的版本的时候，只需要关注三个配置文件，现在直接安装最新的我就不知道了，我是3.0之前一个版本升上来的，到了3.0之后直接到3.5,3.6

>         latke.properties
>         local.properties
>         solo.properties

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;上面这几个配置文件的配置方法，在社区有好多，这个地方配置也是最重要的，详情去社区里找吧
## 三、配置Tomcat
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;对于我的博客来说，并没有使用Nginx，对于linux系统来说，当时在搭建的时候从来没用过这个服务器，内心是拒绝的，然后我直接在Tomcat上直接强行把域名绑到Tomcat服务器下的solo项目，具体方法如下：
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1）更改Tomcat默认端口，把默认的8080端口改成80端口，这样就是为了访问不必敲端口号，同时也方便与域名绑定，这样其实也是不用nginx带来最麻烦的事。
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;打开Tomcat下conf文件夹的`server.xml`
```
         <Connector port="8080" protocol="HTTP/1.1" connectionTimeout="20000" redirectPort="8443" />
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;改成：
```
         <Connector port="80" protocol="HTTP/1.1" connectionTimeout="20000" redirectPort="8443" />
```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;并在最后面的 `</Host>` 前面加上`<Context path="" docBase="solo-v3.6.0" debug="0" reloadable="true" />  ` 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; **至此，如果你对Tomcat很熟悉，并且solo那三个配置文件正确的话，打开Tomcat，然后在浏览器上输入你的服务器ip地址，然后你会发现还是打不开，不要忘了阿里云是需要在阿里云控制台打开端口的，打开阿里云你服务器的80端口，然后就可以solo的初始化了，也许这中间会有问题，相信强大的黑客派会给你力量**
## 四、域名绑定
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在之前博客直接访问服务器ip地址`xxx.xxx.xxx.xxx`就可以访问了，域名绑定只需在阿里云控制台上绑定即可
## 五、关于升级solo那些事
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;说真的配置安装这些都不是什么事，去年12底，博客算是正式运行，然而碰到了升级版本这个倒霉鬼，幸亏当时的数据很少，记得那是第一次升级，不是这个地方不对就是那个地方不对，当时也不知怎么想的，到最后直接把数据库和配置的solo直接删了，毕竟不是Windows还有个回收站让你后悔，其实现在想想就是那三个配置文件不对，也是当时对这个不是很熟悉，就像现在对3.0以上的版本也不是很熟悉一样，但是用了两天之后，还是感觉比之前的版本强不少，毕竟是升级版。**总之，升级的时候一定要备份！备份配置文件，数据库！**
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;再一次升级就是最近了，这次学聪明了，备份了，还好，也没发生什么大问题，3.0之前一个版本一个版本的来，到了3.0发现登录不上，还是咨询了Dl哥，在此感谢！3.0以后还是感觉变化挺大的，solo 社区 GitHub 账户同步，也是费了点时间，搞的之前的社区账户停用，重新注册。
## 六、SSL证书安装
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;这个真心不难，linux下Tomcat上安装，用阿里云上的，也有详细的过程，只需要注意改成了https之后，solo配置文件 `latke.properties`中`serverScheme=http`要改成`serverScheme=https`不改的话会造成页面排版错误
## END
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;现在搭建了这个博客，最后悔的是没有用nginx，造成了现在的Tomcat只能运行solo博客，这个在之后有时间了再改，部署solo博客有好几种方法，适合自己最重要，虽然是之前搭建的，但现在感觉还是挺麻烦的。在未来的日子里，希望更好的融入到solo中，随着版本更新，功能也越来越强，一起加油了！