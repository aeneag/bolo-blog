title: 【毕设_8】需求分析结束（之后补），敲代码ing
date: '2019-03-14 12:38:41'
updated: '2019-04-19 21:01:03'
tags: [毕设, C语言, stm32]
permalink: /articles/2019/03/14/1552537723673.html
---
![](https://img.hacpai.com/bing/20181203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**一、创建新工程**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;创建的过程中出了点小问题，还是解决了。

**二、模块分工明确**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;工程初具形成，把不同文件分组，代码可读性更强，有利于后期修改，simpleWIFI，光照强度，热感已完成
![58ea1b89f9154dd59c850d35e4877e88ppppp.png](https://img.hacpai.com/file/2019/04/58ea1b89f9154dd59c850d35e4877e88ppppp-36f0143a.png)
**三、下一步**
---

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;对光强热感进行中断，按键中断，继电器， 